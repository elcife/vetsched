--
-- PostgreSQL database dump
--

\restrict vyJOpKtJLygkwGLxIpNc5ynPKPTaNpbBCLSEebDNKnLqoYStfAg3M0f3mslxwee

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

-- Started on 2026-09-13 05:18:38

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 220 (class 1259 OID 16523)
-- Name: account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account (
    student_id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255),
    first_name character varying(100),
    last_name character varying(100)
);


ALTER TABLE public.account OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16522)
-- Name: account_student_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_student_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.account_student_id_seq OWNER TO postgres;

--
-- TOC entry 4992 (class 0 OID 0)
-- Dependencies: 219
-- Name: account_student_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_student_id_seq OWNED BY public.account.student_id;


--
-- TOC entry 226 (class 1259 OID 16554)
-- Name: instructor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.instructor (
    instructor_id integer NOT NULL,
    instructor_name character varying(150)
);


ALTER TABLE public.instructor OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 16553)
-- Name: instructor_instructor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.instructor_instructor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.instructor_instructor_id_seq OWNER TO postgres;

--
-- TOC entry 4993 (class 0 OID 0)
-- Dependencies: 225
-- Name: instructor_instructor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.instructor_instructor_id_seq OWNED BY public.instructor.instructor_id;


--
-- TOC entry 232 (class 1259 OID 16580)
-- Name: offering; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offering (
    offering_id integer NOT NULL,
    subject_id bigint,
    room_id integer,
    instructor_id integer,
    max_capacity integer NOT NULL,
    schedule_id integer,
    section_id integer
);


ALTER TABLE public.offering OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 16579)
-- Name: offering_offering_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.offering_offering_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.offering_offering_id_seq OWNER TO postgres;

--
-- TOC entry 4994 (class 0 OID 0)
-- Dependencies: 231
-- Name: offering_offering_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.offering_offering_id_seq OWNED BY public.offering.offering_id;


--
-- TOC entry 234 (class 1259 OID 16619)
-- Name: plotting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plotting (
    plot_id integer NOT NULL,
    student_id integer,
    offering_id integer,
    status character varying(50) NOT NULL,
    approved_by character varying(100) NOT NULL,
    approved_at date NOT NULL
);


ALTER TABLE public.plotting OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 16618)
-- Name: plotting_plot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plotting_plot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plotting_plot_id_seq OWNER TO postgres;

--
-- TOC entry 4995 (class 0 OID 0)
-- Dependencies: 233
-- Name: plotting_plot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plotting_plot_id_seq OWNED BY public.plotting.plot_id;


--
-- TOC entry 228 (class 1259 OID 16562)
-- Name: room; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room (
    room_id integer NOT NULL,
    building character varying(100),
    room_num character varying(50)
);


ALTER TABLE public.room OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 16561)
-- Name: room_room_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.room_room_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.room_room_id_seq OWNER TO postgres;

--
-- TOC entry 4996 (class 0 OID 0)
-- Dependencies: 227
-- Name: room_room_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.room_room_id_seq OWNED BY public.room.room_id;


--
-- TOC entry 230 (class 1259 OID 16570)
-- Name: schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule (
    schedule_id integer NOT NULL,
    offering_id integer,
    day_of_the_week character varying(20),
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL
);


ALTER TABLE public.schedule OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 16569)
-- Name: schedule_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_schedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedule_schedule_id_seq OWNER TO postgres;

--
-- TOC entry 4997 (class 0 OID 0)
-- Dependencies: 229
-- Name: schedule_schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_schedule_id_seq OWNED BY public.schedule.schedule_id;


--
-- TOC entry 222 (class 1259 OID 16536)
-- Name: section; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.section (
    section_id integer NOT NULL,
    section_name character varying(100)
);


ALTER TABLE public.section OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16535)
-- Name: section_section_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.section_section_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.section_section_id_seq OWNER TO postgres;

--
-- TOC entry 4998 (class 0 OID 0)
-- Dependencies: 221
-- Name: section_section_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.section_section_id_seq OWNED BY public.section.section_id;


--
-- TOC entry 224 (class 1259 OID 16544)
-- Name: subject; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subject (
    subject_id bigint NOT NULL,
    subject_code character(10) NOT NULL,
    subject_name character varying(150) NOT NULL
);


ALTER TABLE public.subject OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 16543)
-- Name: subject_subject_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subject_subject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subject_subject_id_seq OWNER TO postgres;

--
-- TOC entry 4999 (class 0 OID 0)
-- Dependencies: 223
-- Name: subject_subject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subject_subject_id_seq OWNED BY public.subject.subject_id;


--
-- TOC entry 4790 (class 2604 OID 16526)
-- Name: account student_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account ALTER COLUMN student_id SET DEFAULT nextval('public.account_student_id_seq'::regclass);


--
-- TOC entry 4793 (class 2604 OID 16557)
-- Name: instructor instructor_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructor ALTER COLUMN instructor_id SET DEFAULT nextval('public.instructor_instructor_id_seq'::regclass);


--
-- TOC entry 4796 (class 2604 OID 16583)
-- Name: offering offering_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offering ALTER COLUMN offering_id SET DEFAULT nextval('public.offering_offering_id_seq'::regclass);


--
-- TOC entry 4797 (class 2604 OID 16622)
-- Name: plotting plot_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plotting ALTER COLUMN plot_id SET DEFAULT nextval('public.plotting_plot_id_seq'::regclass);


--
-- TOC entry 4794 (class 2604 OID 16565)
-- Name: room room_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room ALTER COLUMN room_id SET DEFAULT nextval('public.room_room_id_seq'::regclass);


--
-- TOC entry 4795 (class 2604 OID 16573)
-- Name: schedule schedule_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule ALTER COLUMN schedule_id SET DEFAULT nextval('public.schedule_schedule_id_seq'::regclass);


--
-- TOC entry 4791 (class 2604 OID 16539)
-- Name: section section_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.section ALTER COLUMN section_id SET DEFAULT nextval('public.section_section_id_seq'::regclass);


--
-- TOC entry 4792 (class 2604 OID 16547)
-- Name: subject subject_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subject ALTER COLUMN subject_id SET DEFAULT nextval('public.subject_subject_id_seq'::regclass);


--
-- TOC entry 4972 (class 0 OID 16523)
-- Dependencies: 220
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account (student_id, email, password_hash, first_name, last_name) FROM stdin;
\.


--
-- TOC entry 4978 (class 0 OID 16554)
-- Dependencies: 226
-- Data for Name: instructor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.instructor (instructor_id, instructor_name) FROM stdin;
4	CHATGPT
\.


--
-- TOC entry 4984 (class 0 OID 16580)
-- Dependencies: 232
-- Data for Name: offering; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offering (offering_id, subject_id, room_id, instructor_id, max_capacity, schedule_id, section_id) FROM stdin;
2	2	4	4	0	4	4
\.


--
-- TOC entry 4986 (class 0 OID 16619)
-- Dependencies: 234
-- Data for Name: plotting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plotting (plot_id, student_id, offering_id, status, approved_by, approved_at) FROM stdin;
\.


--
-- TOC entry 4980 (class 0 OID 16562)
-- Dependencies: 228
-- Data for Name: room; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room (room_id, building, room_num) FROM stdin;
1	Main	101
4	WDaD	
\.


--
-- TOC entry 4982 (class 0 OID 16570)
-- Dependencies: 230
-- Data for Name: schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule (schedule_id, offering_id, day_of_the_week, start_time, end_time) FROM stdin;
1	\N	Mon	09:00:00	10:00:00
4	\N	Mon	00:30:00	23:00:00
\.


--
-- TOC entry 4974 (class 0 OID 16536)
-- Dependencies: 222
-- Data for Name: section; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.section (section_id, section_name) FROM stdin;
4	VETASCHED
\.


--
-- TOC entry 4976 (class 0 OID 16544)
-- Dependencies: 224
-- Data for Name: subject; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subject (subject_id, subject_code, subject_name) FROM stdin;
2	VET003    	VETSCHED
\.


--
-- TOC entry 5000 (class 0 OID 0)
-- Dependencies: 219
-- Name: account_student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_student_id_seq', 1, false);


--
-- TOC entry 5001 (class 0 OID 0)
-- Dependencies: 225
-- Name: instructor_instructor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.instructor_instructor_id_seq', 4, true);


--
-- TOC entry 5002 (class 0 OID 0)
-- Dependencies: 231
-- Name: offering_offering_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.offering_offering_id_seq', 2, true);


--
-- TOC entry 5003 (class 0 OID 0)
-- Dependencies: 233
-- Name: plotting_plot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plotting_plot_id_seq', 1, false);


--
-- TOC entry 5004 (class 0 OID 0)
-- Dependencies: 227
-- Name: room_room_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.room_room_id_seq', 4, true);


--
-- TOC entry 5005 (class 0 OID 0)
-- Dependencies: 229
-- Name: schedule_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_schedule_id_seq', 4, true);


--
-- TOC entry 5006 (class 0 OID 0)
-- Dependencies: 221
-- Name: section_section_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.section_section_id_seq', 4, true);


--
-- TOC entry 5007 (class 0 OID 0)
-- Dependencies: 223
-- Name: subject_subject_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subject_subject_id_seq', 2, true);


--
-- TOC entry 4799 (class 2606 OID 16534)
-- Name: account account_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_email_key UNIQUE (email);


--
-- TOC entry 4801 (class 2606 OID 16532)
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (student_id);


--
-- TOC entry 4807 (class 2606 OID 16560)
-- Name: instructor instructor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructor
    ADD CONSTRAINT instructor_pkey PRIMARY KEY (instructor_id);


--
-- TOC entry 4813 (class 2606 OID 16587)
-- Name: offering offering_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offering
    ADD CONSTRAINT offering_pkey PRIMARY KEY (offering_id);


--
-- TOC entry 4815 (class 2606 OID 16628)
-- Name: plotting plotting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plotting
    ADD CONSTRAINT plotting_pkey PRIMARY KEY (plot_id);


--
-- TOC entry 4809 (class 2606 OID 16568)
-- Name: room room_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_pkey PRIMARY KEY (room_id);


--
-- TOC entry 4811 (class 2606 OID 16578)
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (schedule_id);


--
-- TOC entry 4803 (class 2606 OID 16542)
-- Name: section section_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT section_pkey PRIMARY KEY (section_id);


--
-- TOC entry 4805 (class 2606 OID 16552)
-- Name: subject subject_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subject
    ADD CONSTRAINT subject_pkey PRIMARY KEY (subject_id);


--
-- TOC entry 4816 (class 2606 OID 16613)
-- Name: schedule fk_schedule_offering; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT fk_schedule_offering FOREIGN KEY (offering_id) REFERENCES public.offering(offering_id) ON DELETE CASCADE;


--
-- TOC entry 4817 (class 2606 OID 16598)
-- Name: offering offering_instructor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offering
    ADD CONSTRAINT offering_instructor_id_fkey FOREIGN KEY (instructor_id) REFERENCES public.instructor(instructor_id) ON DELETE SET NULL;


--
-- TOC entry 4818 (class 2606 OID 16593)
-- Name: offering offering_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offering
    ADD CONSTRAINT offering_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.room(room_id) ON DELETE SET NULL;


--
-- TOC entry 4819 (class 2606 OID 16603)
-- Name: offering offering_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offering
    ADD CONSTRAINT offering_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.schedule(schedule_id) ON DELETE SET NULL;


--
-- TOC entry 4820 (class 2606 OID 16608)
-- Name: offering offering_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offering
    ADD CONSTRAINT offering_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.section(section_id) ON DELETE SET NULL;


--
-- TOC entry 4821 (class 2606 OID 16588)
-- Name: offering offering_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offering
    ADD CONSTRAINT offering_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subject(subject_id) ON DELETE SET NULL;


--
-- TOC entry 4822 (class 2606 OID 16634)
-- Name: plotting plotting_offering_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plotting
    ADD CONSTRAINT plotting_offering_id_fkey FOREIGN KEY (offering_id) REFERENCES public.offering(offering_id) ON DELETE CASCADE;


--
-- TOC entry 4823 (class 2606 OID 16629)
-- Name: plotting plotting_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plotting
    ADD CONSTRAINT plotting_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.account(student_id) ON DELETE CASCADE;


-- Completed on 2026-09-13 05:18:39

--
-- PostgreSQL database dump complete
--

\unrestrict vyJOpKtJLygkwGLxIpNc5ynPKPTaNpbBCLSEebDNKnLqoYStfAg3M0f3mslxwee


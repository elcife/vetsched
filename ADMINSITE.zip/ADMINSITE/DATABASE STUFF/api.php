<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

require_once __DIR__ . '/db.php';


function respond($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data);
    exit;
}

function requestData() {
    $body = json_decode(file_get_contents('php://input'), true);
    return is_array($body) ? $body : [];
}

$resource = $_GET['resource'] ?? '';

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if ($resource === 'subjects') {
            $rows = $conn->query('SELECT subject_id AS id, TRIM(subject_code) AS code, subject_name AS name FROM subject ORDER BY subject_id')->fetchAll(PDO::FETCH_ASSOC);
            respond($rows);
        }

        if ($resource === 'sections') {
            $sql = "SELECT s.section_id AS id, s.section_name AS type,
                           o.subject_id AS \"subjectId\", o.max_capacity AS \"maxCapacity\",
                           i.instructor_name AS instructor,
                           CONCAT_WS(', ', r.building, r.room_num) AS room,
                           sc.day_of_the_week AS day, sc.start_time AS start, sc.end_time AS \"end\"
                    FROM section s
                    LEFT JOIN offering o ON o.section_id = s.section_id
                    LEFT JOIN instructor i ON i.instructor_id = o.instructor_id
                    LEFT JOIN room r ON r.room_id = o.room_id
                    LEFT JOIN schedule sc ON sc.schedule_id = o.schedule_id
                    ORDER BY s.section_id";
            $rows = $conn->query($sql)->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as &$row) {
                $row['days'] = $row['day'] ? [$row['day']] : [];
                unset($row['day']);
            }
            respond($rows);
        }

        if ($resource === 'students') {
            $sql = "SELECT student_id AS id, student_id AS \"studentId\",
                           CONCAT_WS(' ', first_name, last_name) AS name
                    FROM account ORDER BY student_id";
            respond($conn->query($sql)->fetchAll(PDO::FETCH_ASSOC));
        }

        respond(['success' => false, 'message' => 'Unknown resource'], 404);
    }

    $data = requestData();
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        respond(['success' => false, 'message' => 'POST required'], 405);
    }

    if ($resource === 'subjects') {
        $code = trim((string) ($data['code'] ?? ''));
        $name = trim((string) ($data['name'] ?? ''));
        if ($code === '' || $name === '') {
            respond(['success' => false, 'message' => 'Subject code and name are required'], 400);
        }
        if (strlen($code) > 10) {
            respond(['success' => false, 'message' => 'Subject code must be 10 characters or fewer'], 400);
        }
        if (!empty($data['id']) && is_numeric($data['id'])) {
            $stmt = $conn->prepare('UPDATE subject SET subject_code = :code, subject_name = :name WHERE subject_id = :id');
            $stmt->execute([':id' => $data['id'], ':code' => $code, ':name' => $name]);
            $id = (int) $data['id'];
        } else {
            $stmt = $conn->prepare('INSERT INTO subject (subject_code, subject_name) VALUES (:code, :name) RETURNING subject_id');
            $stmt->execute([':code' => $code, ':name' => $name]);
            $id = (int) $stmt->fetchColumn();
        }
        respond(['success' => true, 'id' => $id, 'code' => $code, 'name' => $name]);
    }

    if ($resource === 'sections') {
        foreach (['type', 'subjectId', 'instructor', 'start', 'end'] as $required) {
            if (empty($data[$required])) {
                respond(['success' => false, 'message' => "Missing section field: $required"], 400);
            }
        }
        $conn->beginTransaction();

        if (!empty($data['id']) && is_numeric($data['id'])) {
            $sectionId = (int) $data['id'];
            $stmt = $conn->prepare('UPDATE section SET section_name = :name WHERE section_id = :id');
            $stmt->execute([':id' => $sectionId, ':name' => $data['type']]);
        } else {
            $stmt = $conn->prepare('INSERT INTO section (section_name) VALUES (:name) RETURNING section_id');
            $stmt->execute([':name' => $data['type']]);
            $sectionId = (int) $stmt->fetchColumn();
        }

        $instructorStmt = $conn->prepare('INSERT INTO instructor (instructor_name) VALUES (:name) RETURNING instructor_id');
        $instructorStmt->execute([':name' => $data['instructor']]);
        $instructorId = (int) $instructorStmt->fetchColumn();

        $roomId = null;
        if (!empty($data['room'])) {
            $parts = array_map('trim', explode(',', $data['room'], 2));
            $roomStmt = $conn->prepare('INSERT INTO room (building, room_num) VALUES (:building, :room) RETURNING room_id');
            $roomStmt->execute([':building' => $parts[0], ':room' => $parts[1] ?? '']);
            $roomId = (int) $roomStmt->fetchColumn();
        }

        $day = is_array($data['days'] ?? null) ? ($data['days'][0] ?? '') : ($data['days'] ?? '');
        $scheduleStmt = $conn->prepare('INSERT INTO schedule (day_of_the_week, start_time, end_time) VALUES (:day, :start, :end) RETURNING schedule_id');
        $scheduleStmt->execute([':day' => $day, ':start' => $data['start'], ':end' => $data['end']]);
        $scheduleId = (int) $scheduleStmt->fetchColumn();

        $offeringStmt = $conn->prepare('SELECT offering_id FROM offering WHERE section_id = :section LIMIT 1');
        $offeringStmt->execute([':section' => $sectionId]);
        $offeringId = $offeringStmt->fetchColumn();
        if ($offeringId) {
            $stmt = $conn->prepare('UPDATE offering SET subject_id = :subject, room_id = :room, instructor_id = :instructor, max_capacity = :capacity, schedule_id = :schedule WHERE offering_id = :id');
            $stmt->execute([':id' => $offeringId, ':subject' => $data['subjectId'], ':room' => $roomId, ':instructor' => $instructorId, ':capacity' => $data['maxCapacity'] ?? 0, ':schedule' => $scheduleId]);
        } else {
            $stmt = $conn->prepare('INSERT INTO offering (subject_id, room_id, instructor_id, max_capacity, schedule_id, section_id) VALUES (:subject, :room, :instructor, :capacity, :schedule, :section)');
            $stmt->execute([':subject' => $data['subjectId'], ':room' => $roomId, ':instructor' => $instructorId, ':capacity' => $data['maxCapacity'] ?? 0, ':schedule' => $scheduleId, ':section' => $sectionId]);
        }
        $conn->commit();
        respond(['success' => true, 'id' => $sectionId]);
    }

    if ($resource === 'students') {
        if (empty($data['studentId']) || !is_numeric($data['studentId']) || empty($data['name'])) {
            respond(['success' => false, 'message' => 'Student ID and name are required'], 400);
        }
        $nameParts = preg_split('/\s+/', trim($data['name']), 2);
        $email = strtolower($data['studentId']) . '@vetsched.local';
        $params = [
            ':id' => $data['studentId'],
            ':email' => $email,
            ':first' => $nameParts[0],
            ':last' => $nameParts[1] ?? ''
        ];
        if (!empty($data['id']) && is_numeric($data['id'])) {
            $stmt = $conn->prepare('UPDATE account SET first_name = :first, last_name = :last WHERE student_id = :existing_id');
            $params[':existing_id'] = $data['id'];
        } else {
            $stmt = $conn->prepare('INSERT INTO account (student_id, email, first_name, last_name) VALUES (:id, :email, :first, :last)');
        }
        $stmt->execute($params);
        respond(['success' => true, 'id' => (int) ($data['id'] ?? $data['studentId'])]);
    }

    respond(['success' => false, 'message' => 'Unknown resource'], 404);
} catch (Throwable $e) {
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    respond(['success' => false, 'message' => $e->getMessage()], 500);
}
?>
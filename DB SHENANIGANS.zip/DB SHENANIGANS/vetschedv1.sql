--
-- PostgreSQL database dump
--

\restrict 2KGipUu9SBqZHvX0vC0lEOe3YumwbyNI54vTcHGF8WkRSKQsRxD10ksoae2awnI

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

-- Started on 2026-09-02 04:59:49

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 219 (class 1259 OID 16392)
-- Name: account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account (
    student_id character varying(50) CONSTRAINT account_student_number_not_null NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(200),
    password character varying(255)
);


ALTER TABLE public.account OWNER TO postgres;

--
-- TOC entry 4903 (class 0 OID 16392)
-- Dependencies: 219
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account (student_id, first_name, last_name, email, password) FROM stdin;
05-2324-030036	Sean	Garcia	sema.garcia.swu@phinmaed.com	$2y$10$r9pBJukUBoa2ZlEsoXlwveO491RCMcBMu5kXicoXRvyUQPKOFC4QS
\.


--
-- TOC entry 4755 (class 2606 OID 16408)
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (student_id);


-- Completed on 2026-09-02 04:59:49

--
-- PostgreSQL database dump complete
--

\unrestrict 2KGipUu9SBqZHvX0vC0lEOe3YumwbyNI54vTcHGF8WkRSKQsRxD10ksoae2awnI


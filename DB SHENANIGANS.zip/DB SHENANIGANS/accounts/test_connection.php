<?php
require_once "db.php";
echo "PostgreSQL connection successful!";
?>

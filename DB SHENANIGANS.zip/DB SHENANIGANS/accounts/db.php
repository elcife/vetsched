<?php
$host = "localhost";
$port = "5432";
$dbname = "vetsched";
$username = "postgres";
$password = "root";
try {
  $conn = new PDO(
    "pgsql:host=$host;port=$port;dbname=$dbname",
    $username, $password
  );
  $conn->setAttribute(PDO::ATTR_ERRMODE,
                      PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  die("Database connection failed: " . $e->getMessage());
}
?>

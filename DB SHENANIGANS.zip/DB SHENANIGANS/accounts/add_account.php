<?php
header("Content-Type: application/json");
require_once "db.php";

$data = json_decode(file_get_contents("php://input"), true);

if (empty($data["first_name"]) || empty($data["last_name"]) ||
    empty($data["email"]) || empty($data["student_id"]) ||
    empty($data["password"])) {

    http_response_code(400);
    echo json_encode(["success" => false, "message" => "All fields are required"]);
    exit;
}

// Enforce 10 character minimum
if (strlen($data["password"]) < 10) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Password must be at least 10 characters"]);
    exit;
}

try {
    // Hash the password for security
    $hashedPassword = password_hash($data["password"], PASSWORD_DEFAULT);

    $sql = "INSERT INTO account (student_id, first_name, last_name, email, password)
            VALUES (:student_id, :first_name, :last_name, :email, :password)";

    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ":student_id" => $data["student_id"],
        ":first_name" => $data["first_name"],
        ":last_name"  => $data["last_name"],
        ":email"      => $data["email"],
        ":password"   => $hashedPassword
    ]);

    echo json_encode(["success" => true, "message" => "Account created successfully"]);

} catch (PDOException $e) {
    http_response_code(500);
    if ($e->getCode() == 23505) {
        echo json_encode(["success" => false, "message" => "Email or Student ID already registered"]);
    } else {
        echo json_encode(["success" => false, "message" => "DB Error: " . $e->getMessage()]);
    }
}
?>
